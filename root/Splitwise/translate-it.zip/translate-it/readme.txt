Translate-It Translation tool
Author  : Jon Raasch
Website : http://jonraasch.com/blog/
Email   : jr@jonraasch.com

Copyright (c)2008 Jon Raasch



##############################
       FreeBSD License     
##############################
##############################

Copyright (c)2008 Jon Raasch. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

	1.	Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
	2.	Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
	
THIS SOFTWARE IS PROVIDED BY JON RAASCH ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JON RAASCH OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those of the authors and should not be interpreted as representing official policies, either expressed or implied, of Jon Raasch, who is the man.


    
##############################
         Instructions   
##############################
##############################

Translate-It makes multi-language translation easy to implement on any website.  With just a few lines of Javascript you can quickly include up to 34 languages of internationalization on your site.

Integrating Translate-It into your website is a piece of cake.  Just upload the translate-it.js file to your website, and include these lines of Javascript:

<script type="text/javascript" src="translate-it.js"></script>

<script type="text/javascript">
TranslateIt.init();
</script>

Make sure to modify the path to translate-it.js if necessary.

Finally, add this HTML wherever you want the flag icons on your page:

<div id="translateFlags"></div>

And that's it, your website has become much more global, with translation into tons of languages!


##############################
   Customizing Translate-It
##############################
##############################

To customize Translate-It, first open up translate-it.js and look towards the top for the config section.  This is the area that is easy to modify and any non-developers should only work within this section.

There are only 10 languages enabled by default, but including up to 34 languages is simple, just edit the 'usedLangs' array.  You can also change the order that the flags appear with this array.  Just make sure that the last item doesn't have a comma at the end, or it will throw an error in IE.

Additionally, if you want to use your own imagery, or just want to host the flags locally, you can modify the 'bgImage' variable.  If you do want to style the flags yourself, you'll want to set 'useFlagCSS' and 'useWrapperCSS' to 0 (zero).

If your site is in a language other than English to begin with, make sure to change the 'fromLang' variable.

Finally, if you want to use a different id than 'translateFlags', either set the 'flagsWrap' variable statically, or pass the id into TranslateIt.init() to change it on the fly.